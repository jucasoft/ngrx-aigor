// import * as effectsO from '@ngrx/effects';
// import {applyHandlerStackTraceOfType} from '../utils/aigor-proxy';
//
// const ofType = new Proxy(effectsO.ofType, applyHandlerStackTraceOfType);
//
// const effects: any = {...effectsO, ofType};
//
// export {effects};
